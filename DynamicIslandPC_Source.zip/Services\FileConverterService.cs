using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace DynamicIsland.Services
{
    public class ConvertResult
    {
        public bool Success { get; set; }
        public string OutputPath { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
    }

    public static class FileConverterService
    {
        public static async Task<ConvertResult> ConvertAsync(string inputPath, string targetFormat)
        {
            return await Task.Run(() =>
            {
                var result = new ConvertResult();
                try
                {
                    if (!File.Exists(inputPath))
                    {
                        result.Success = false;
                        result.Message = "Arquivo de origem não encontrado.";
                        return result;
                    }

                    string dir = Path.GetDirectoryName(inputPath) ?? Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                    string fileNameWithoutExt = Path.GetFileNameWithoutExtension(inputPath);
                    string srcExt = Path.GetExtension(inputPath).ToLowerInvariant();
                    string targetExt = targetFormat.ToLowerInvariant().TrimStart('.');
                    string outPath = Path.Combine(dir, $"{fileNameWithoutExt}_convertido.{targetExt}");

                    // Avoid overwriting - add number if file exists
                    int counter = 1;
                    while (File.Exists(outPath))
                    {
                        outPath = Path.Combine(dir, $"{fileNameWithoutExt}_convertido_{counter}.{targetExt}");
                        counter++;
                    }

                    // ===== IMAGE CONVERSIONS =====
                    if (IsImageExtension(srcExt) && IsImageExtension("." + targetExt))
                    {
                        using var imgStream = File.OpenRead(inputPath);
                        var decoder = System.Windows.Media.Imaging.BitmapDecoder.Create(
                            imgStream,
                            System.Windows.Media.Imaging.BitmapCreateOptions.None,
                            System.Windows.Media.Imaging.BitmapCacheOption.OnLoad);
                        var frame = decoder.Frames[0];

                        System.Windows.Media.Imaging.BitmapEncoder encoder = targetExt switch
                        {
                            "jpg" or "jpeg" => new System.Windows.Media.Imaging.JpegBitmapEncoder { QualityLevel = 92 },
                            "png" => new System.Windows.Media.Imaging.PngBitmapEncoder(),
                            "bmp" => new System.Windows.Media.Imaging.BmpBitmapEncoder(),
                            "gif" => new System.Windows.Media.Imaging.GifBitmapEncoder(),
                            _ => new System.Windows.Media.Imaging.PngBitmapEncoder()
                        };

                        encoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(frame));
                        using var outStream = File.Create(outPath);
                        encoder.Save(outStream);

                        result.Success = true;
                        result.OutputPath = outPath;
                        result.Message = $"Imagem convertida para .{targetExt} com sucesso!";
                        return result;
                    }

                    // ===== PDF TEXT EXTRACTION =====
                    if (srcExt == ".pdf" && (targetExt == "txt" || targetExt == "docx" || targetExt == "html"))
                    {
                        string extractedText = ExtractTextFromPdf(inputPath);
                        if (string.IsNullOrWhiteSpace(extractedText))
                        {
                            extractedText = "[Não foi possível extrair texto deste PDF. O arquivo pode conter apenas imagens ou estar protegido.]";
                        }

                        if (targetExt == "txt")
                        {
                            File.WriteAllText(outPath, extractedText, Encoding.UTF8);
                            result.Success = true;
                            result.OutputPath = outPath;
                            result.Message = "Texto extraído do PDF para .txt!";
                            return result;
                        }
                        else if (targetExt == "docx")
                        {
                            CreateBasicDocx(outPath, extractedText);
                            result.Success = true;
                            result.OutputPath = outPath;
                            result.Message = "PDF convertido para .docx com sucesso!";
                            return result;
                        }
                        else if (targetExt == "html")
                        {
                            string html = CreateHtmlFromText(fileNameWithoutExt, extractedText);
                            File.WriteAllText(outPath, html, Encoding.UTF8);
                            result.Success = true;
                            result.OutputPath = outPath;
                            result.Message = "PDF convertido para .html!";
                            return result;
                        }
                    }

                    // ===== DOCX EXTRACTION =====
                    if (srcExt == ".docx")
                    {
                        string docxText = ExtractTextFromDocx(inputPath);

                        if (targetExt == "txt")
                        {
                            File.WriteAllText(outPath, docxText, Encoding.UTF8);
                            result.Success = true;
                            result.OutputPath = outPath;
                            result.Message = "Texto do DOCX extraído para .txt!";
                            return result;
                        }
                        else if (targetExt == "html")
                        {
                            string html = CreateHtmlFromText(fileNameWithoutExt, docxText);
                            File.WriteAllText(outPath, html, Encoding.UTF8);
                            result.Success = true;
                            result.OutputPath = outPath;
                            result.Message = "DOCX convertido para .html!";
                            return result;
                        }
                        else if (targetExt == "pdf")
                        {
                            // Create a basic PDF from text content
                            string text = ExtractTextFromDocx(inputPath);
                            CreateBasicPdf(outPath, text);
                            result.Success = true;
                            result.OutputPath = outPath;
                            result.Message = "DOCX convertido para .pdf!";
                            return result;
                        }
                    }

                    // ===== TEXT-BASED FILE CONVERSIONS =====
                    if (IsTextExtension(srcExt))
                    {
                        string content = File.ReadAllText(inputPath, Encoding.UTF8);

                        if (targetExt == "html")
                        {
                            string html = CreateHtmlFromText(fileNameWithoutExt, content);
                            File.WriteAllText(outPath, html, Encoding.UTF8);
                            result.Success = true;
                            result.OutputPath = outPath;
                            result.Message = "Convertido para HTML!";
                            return result;
                        }
                        if (targetExt == "txt" || targetExt == "csv" || targetExt == "md" || targetExt == "log")
                        {
                            File.WriteAllText(outPath, content, Encoding.UTF8);
                            result.Success = true;
                            result.OutputPath = outPath;
                            result.Message = $"Convertido para .{targetExt}!";
                            return result;
                        }
                        if (targetExt == "docx")
                        {
                            CreateBasicDocx(outPath, content);
                            result.Success = true;
                            result.OutputPath = outPath;
                            result.Message = "Convertido para .docx!";
                            return result;
                        }
                        if (targetExt == "pdf")
                        {
                            CreateBasicPdf(outPath, content);
                            result.Success = true;
                            result.OutputPath = outPath;
                            result.Message = "Convertido para .pdf!";
                            return result;
                        }
                    }

                    result.Success = false;
                    result.Message = $"Conversão de {srcExt} para .{targetExt} não suportada.";
                }
                catch (Exception ex)
                {
                    result.Success = false;
                    result.Message = "Erro ao converter: " + ex.Message;
                }

                return result;
            });
        }

        private static bool IsImageExtension(string ext)
        {
            return ext is ".jpg" or ".jpeg" or ".png" or ".bmp" or ".gif" or ".ico" or ".webp";
        }

        private static bool IsTextExtension(string ext)
        {
            return ext is ".txt" or ".md" or ".log" or ".csv" or ".json" or ".xml" or ".ini" or ".cfg" or ".yaml" or ".yml";
        }

        /// <summary>
        /// Extract text from PDF by parsing the raw PDF content streams.
        /// This is a basic implementation that handles common text-based PDFs.
        /// </summary>
        private static string ExtractTextFromPdf(string pdfPath)
        {
            try
            {
                byte[] pdfBytes = File.ReadAllBytes(pdfPath);
                string rawContent = Encoding.Latin1.GetString(pdfBytes);
                var sb = new StringBuilder();

                // Method 1: Extract text from BT...ET blocks (text objects)
                var btEtMatches = Regex.Matches(rawContent, @"BT\s(.*?)\sET", RegexOptions.Singleline);
                foreach (Match btEt in btEtMatches)
                {
                    string textBlock = btEt.Groups[1].Value;

                    // Extract text from Tj operator (show string)
                    var tjMatches = Regex.Matches(textBlock, @"\(([^)]*)\)\s*Tj");
                    foreach (Match tj in tjMatches)
                    {
                        string text = DecodePdfString(tj.Groups[1].Value);
                        sb.Append(text);
                    }

                    // Extract text from TJ operator (show array of strings)
                    var tjArrayMatches = Regex.Matches(textBlock, @"\[([^\]]*)\]\s*TJ", RegexOptions.IgnoreCase);
                    foreach (Match tjArr in tjArrayMatches)
                    {
                        var innerMatches = Regex.Matches(tjArr.Groups[1].Value, @"\(([^)]*)\)");
                        foreach (Match inner in innerMatches)
                        {
                            string text = DecodePdfString(inner.Groups[1].Value);
                            sb.Append(text);
                        }
                    }

                    // Check for line breaks (Td, TD, T*, ' operators)
                    if (Regex.IsMatch(textBlock, @"\b(Td|TD|T\*)\b"))
                    {
                        if (sb.Length > 0 && sb[sb.Length - 1] != '\n')
                            sb.AppendLine();
                    }
                }

                // Method 2: If BT/ET extraction failed, try stream decompression
                if (sb.Length < 10)
                {
                    // Try to find plain text patterns in the raw content
                    var plainTextMatches = Regex.Matches(rawContent, @"\(([^)]{3,})\)");
                    foreach (Match m in plainTextMatches)
                    {
                        string candidate = DecodePdfString(m.Groups[1].Value);
                        // Filter out binary/control character strings
                        if (candidate.Length > 2 && Regex.IsMatch(candidate, @"[a-zA-ZÀ-ÿ0-9]"))
                        {
                            sb.Append(candidate).Append(" ");
                        }
                    }
                }

                string result = sb.ToString().Trim();
                // Clean up excessive whitespace
                result = Regex.Replace(result, @"[ \t]{3,}", "  ");
                result = Regex.Replace(result, @"\n{3,}", "\n\n");
                return result;
            }
            catch
            {
                return string.Empty;
            }
        }

        private static string DecodePdfString(string pdfStr)
        {
            // Handle common PDF escape sequences
            pdfStr = pdfStr.Replace(@"\n", "\n")
                           .Replace(@"\r", "\r")
                           .Replace(@"\t", "\t")
                           .Replace(@"\(", "(")
                           .Replace(@"\)", ")")
                           .Replace(@"\\", "\\");

            // Handle octal escapes like \050
            pdfStr = Regex.Replace(pdfStr, @"\\([0-7]{1,3})", m =>
            {
                int code = Convert.ToInt32(m.Groups[1].Value, 8);
                return ((char)code).ToString();
            });

            return pdfStr;
        }

        private static string ExtractTextFromDocx(string docxPath)
        {
            try
            {
                using var zip = System.IO.Compression.ZipFile.OpenRead(docxPath);
                var docXmlEntry = zip.GetEntry("word/document.xml");
                if (docXmlEntry != null)
                {
                    using var reader = new StreamReader(docXmlEntry.Open());
                    string xml = reader.ReadToEnd();
                    string plainText = Regex.Replace(xml, @"<w:p[^>]*?/>", "\r\n");
                    plainText = Regex.Replace(plainText, @"<w:p.*?>", "\r\n");
                    plainText = Regex.Replace(plainText, @"<[^>]+>", "");
                    plainText = System.Net.WebUtility.HtmlDecode(plainText).Trim();
                    return plainText;
                }
            }
            catch { }
            return string.Empty;
        }

        private static string CreateHtmlFromText(string title, string content)
        {
            string encodedContent = System.Net.WebUtility.HtmlEncode(content);
            return $@"<!DOCTYPE html>
<html lang=""pt-BR"">
<head>
    <meta charset=""utf-8"">
    <title>{System.Net.WebUtility.HtmlEncode(title)}</title>
    <style>
        body {{ font-family: 'Segoe UI', Tahoma, sans-serif; padding: 30px; line-height: 1.7; background: #fafafa; color: #333; max-width: 800px; margin: 0 auto; }}
        h1 {{ color: #A855F7; border-bottom: 2px solid #E9D5FF; padding-bottom: 10px; }}
        pre {{ background: #f5f5f5; padding: 20px; border-radius: 8px; overflow-x: auto; white-space: pre-wrap; word-wrap: break-word; }}
    </style>
</head>
<body>
    <h1>{System.Net.WebUtility.HtmlEncode(title)}</h1>
    <pre>{encodedContent}</pre>
</body>
</html>";
        }

        /// <summary>
        /// Create a basic valid PDF file from text content.
        /// Uses raw PDF operators to create a simple text document.
        /// </summary>
        private static void CreateBasicPdf(string pdfPath, string text)
        {
            // Split text into lines, max ~70 chars per line for PDF page width
            var lines = new System.Collections.Generic.List<string>();
            foreach (var rawLine in text.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None))
            {
                if (rawLine.Length <= 80)
                {
                    lines.Add(rawLine);
                }
                else
                {
                    // Word wrap long lines
                    var words = rawLine.Split(' ');
                    var currentLine = new StringBuilder();
                    foreach (var word in words)
                    {
                        if (currentLine.Length + word.Length + 1 > 80 && currentLine.Length > 0)
                        {
                            lines.Add(currentLine.ToString());
                            currentLine.Clear();
                        }
                        if (currentLine.Length > 0) currentLine.Append(' ');
                        currentLine.Append(word);
                    }
                    if (currentLine.Length > 0) lines.Add(currentLine.ToString());
                }
            }

            // Split into pages (~50 lines per page)
            int linesPerPage = 50;
            var pages = new System.Collections.Generic.List<System.Collections.Generic.List<string>>();
            for (int i = 0; i < lines.Count; i += linesPerPage)
            {
                pages.Add(lines.GetRange(i, Math.Min(linesPerPage, lines.Count - i)));
            }
            if (pages.Count == 0) pages.Add(new System.Collections.Generic.List<string> { " " });

            using var fs = File.Create(pdfPath);
            using var writer = new StreamWriter(fs, new UTF8Encoding(false));

            var offsets = new System.Collections.Generic.List<long>();

            writer.Write("%PDF-1.4\n");

            // Object 1: Catalog
            offsets.Add(fs.Position);
            writer.Write("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");
            writer.Flush();

            // Object 2: Pages
            offsets.Add(fs.Position);
            var pageRefs = new StringBuilder();
            for (int i = 0; i < pages.Count; i++)
            {
                pageRefs.Append($"{3 + i * 3} 0 R ");
            }
            writer.Write($"2 0 obj\n<< /Type /Pages /Kids [{pageRefs.ToString().Trim()}] /Count {pages.Count} >>\nendobj\n");
            writer.Flush();

            // Font object (shared)
            int fontObjNum = 3 + pages.Count * 3;
            
            // Create page objects
            for (int p = 0; p < pages.Count; p++)
            {
                int pageObjNum = 3 + p * 3;
                int contentsObjNum = pageObjNum + 1;
                int lengthObjNum = pageObjNum + 2;

                // Build content stream
                var contentStream = new StringBuilder();
                contentStream.Append("BT\n/F1 11 Tf\n36 756 Td\n14 TL\n");
                foreach (var line in pages[p])
                {
                    string escaped = EscapePdfText(line);
                    contentStream.Append($"({escaped}) '\n");
                }
                contentStream.Append("ET\n");
                string streamContent = contentStream.ToString();

                // Page object
                offsets.Add(fs.Position);
                writer.Write($"{pageObjNum} 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents {contentsObjNum} 0 R /Resources << /Font << /F1 {fontObjNum} 0 R >> >> >>\nendobj\n");
                writer.Flush();

                // Contents stream object
                offsets.Add(fs.Position);
                writer.Write($"{contentsObjNum} 0 obj\n<< /Length {streamContent.Length} >>\nstream\n{streamContent}endstream\nendobj\n");
                writer.Flush();

                // Length object (not strictly needed since we inline it, but keep obj count consistent)
                offsets.Add(fs.Position);
                writer.Write($"{lengthObjNum} 0 obj\n{streamContent.Length}\nendobj\n");
                writer.Flush();
            }

            // Font object
            offsets.Add(fs.Position);
            writer.Write($"{fontObjNum} 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n");
            writer.Flush();

            // Cross-reference table
            long xrefStart = fs.Position;
            int totalObjects = fontObjNum;
            writer.Write($"xref\n0 {totalObjects + 1}\n");
            writer.Write("0000000000 65535 f \n");
            for (int i = 0; i < offsets.Count && i < totalObjects; i++)
            {
                writer.Write($"{offsets[i]:D10} 00000 n \n");
            }
            writer.Flush();

            // Trailer
            writer.Write($"trailer\n<< /Size {totalObjects + 1} /Root 1 0 R >>\n");
            writer.Write($"startxref\n{xrefStart}\n%%EOF\n");
        }

        private static string EscapePdfText(string text)
        {
            return text.Replace("\\", "\\\\")
                       .Replace("(", "\\(")
                       .Replace(")", "\\)");
        }

        private static void CreateBasicDocx(string docxPath, string text)
        {
            using var fileStream = File.Create(docxPath);
            using var archive = new System.IO.Compression.ZipArchive(fileStream, System.IO.Compression.ZipArchiveMode.Create);

            var ct = archive.CreateEntry("[Content_Types].xml");
            using (var writer = new StreamWriter(ct.Open()))
            {
                writer.Write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>");
            }

            var rels = archive.CreateEntry("_rels/.rels");
            using (var writer = new StreamWriter(rels.Open()))
            {
                writer.Write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>");
            }

            var doc = archive.CreateEntry("word/document.xml");
            using (var writer = new StreamWriter(doc.Open()))
            {
                var paragraphs = new StringBuilder();
                foreach (var line in text.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None))
                {
                    string safeText = System.Net.WebUtility.HtmlEncode(line);
                    paragraphs.Append($"<w:p><w:r><w:t xml:space=\"preserve\">{safeText}</w:t></w:r></w:p>");
                }
                writer.Write($"<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>{paragraphs}</w:body></w:document>");
            }
        }
    }
}
