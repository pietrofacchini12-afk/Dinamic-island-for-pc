using System;
using System.Data;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace DynamicIsland.Services
{
    public static class AiChatService
    {
        private static readonly HttpClient _httpClient;

        private const string SystemPersonality = 
            "Você é a Aura, a inteligência artificial nativa e inteligente da Dynamic Island PC. " +
            "Sua personalidade é carismática, moderna, amigável, prestativa e bem-humorada, mas sempre direta e objetiva. " +
            "Você conhece o usuário, conversa naturalmente em português brasileiro, sabe fazer piadas leves, tira dúvidas do dia a dia, " +
            "ajuda com trabalho, estudos, programação e curiosidades. " +
            "Se o usuário perguntar 'quem sou eu', responda de forma criativa dizendo que ele é o dono do PC e seu criador/parceiro de produtividade na Dynamic Island. " +
            "Se perguntarem 'quem é você', apresente-se como Aura da Dynamic Island.";

        static AiChatService()
        {
            var handler = new HttpClientHandler
            {
                AutomaticDecompression = System.Net.DecompressionMethods.GZip | System.Net.DecompressionMethods.Deflate,
                ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => true
            };
            _httpClient = new HttpClient(handler) { Timeout = TimeSpan.FromSeconds(12) };
            _httpClient.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
        }

        public static async Task<string> AskAiAsync(string prompt)
        {
            if (string.IsNullOrWhiteSpace(prompt))
                return "Por favor, digite uma pergunta!";

            string cleanPrompt = prompt.Trim();
            string lowerPrompt = cleanPrompt.ToLowerInvariant();

            // 1. Instant Math Calculation Check
            string? mathResult = TryEvaluateMath(cleanPrompt);
            if (mathResult != null)
            {
                return mathResult;
            }

            // 2. Built-in Personality Instant Answers
            if (Regex.IsMatch(lowerPrompt, @"\b(quem\s*sou\s*eu|me\s*conhece|quem\s*eu\s*sou)\b"))
            {
                string userName = Environment.UserName;
                return $"✨ Você é o {userName}, o comandante desta máquina e o criador deste setup com a Dynamic Island! Eu sou a sua assistente e estou aqui para facilitar o seu dia no PC.";
            }

            if (Regex.IsMatch(lowerPrompt, @"\b(quem\s*(?:é|e)\s*voc[êe]|qual\s*(?:é|e)\s*o\s*seu\s*nome|como\s*voc[êe]\s*se\s*chama)\b"))
            {
                return "✨ Eu sou a Aura, a IA inteligente da sua Dynamic Island PC! Posso responder dúvidas, fazer cálculos, traduzir telas, buscar arquivos e ajudar em qualquer tarefa do seu dia a dia.";
            }

            // 3. Primary LLM Provider: OpenAI API (via free reliable endpoint)
            try
            {
                var payload = new
                {
                    messages = new[]
                    {
                        new { role = "system", content = SystemPersonality },
                        new { role = "user", content = cleanPrompt }
                    },
                    model = "openai",
                    seed = Math.Abs(Guid.NewGuid().GetHashCode() % 10000)
                };

                string jsonBody = JsonSerializer.Serialize(payload);
                using var httpContent = new StringContent(jsonBody, Encoding.UTF8, "application/json");

                var response = await _httpClient.PostAsync("https://text.pollinations.ai/", httpContent);
                if (response.IsSuccessStatusCode)
                {
                    string answer = await response.Content.ReadAsStringAsync();
                    if (!string.IsNullOrWhiteSpace(answer) && !answer.StartsWith("<!DOCTYPE", StringComparison.OrdinalIgnoreCase))
                    {
                        return answer.Trim();
                    }
                }
            }
            catch { }

            // 4. Secondary LLM Provider: Mistral/Qwen GET fallback
            try
            {
                string encoded = Uri.EscapeDataString(cleanPrompt);
                string sysParam = Uri.EscapeDataString(SystemPersonality);
                string url = $"https://text.pollinations.ai/{encoded}?model=mistral&system={sysParam}&seed={Math.Abs(Guid.NewGuid().GetHashCode() % 10000)}";
                
                var answer = await _httpClient.GetStringAsync(url);
                if (!string.IsNullOrWhiteSpace(answer) && !answer.StartsWith("<!DOCTYPE", StringComparison.OrdinalIgnoreCase))
                {
                    return answer.Trim();
                }
            }
            catch { }

            // 5. Fallback Instant Knowledge: DuckDuckGo
            try
            {
                string ddgUrl = $"https://api.duckduckgo.com/?q={Uri.EscapeDataString(cleanPrompt)}&format=json&no_html=1&skip_disambig=1";
                string json = await _httpClient.GetStringAsync(ddgUrl);
                using var doc = JsonDocument.Parse(json);
                if (doc.RootElement.TryGetProperty("Answer", out var ans) && !string.IsNullOrWhiteSpace(ans.GetString()))
                {
                    return ans.GetString()!;
                }
                if (doc.RootElement.TryGetProperty("AbstractText", out var abs) && !string.IsNullOrWhiteSpace(abs.GetString()))
                {
                    return abs.GetString()!;
                }
            }
            catch { }

            // 6. Fallback Wikipedia Summary
            try
            {
                string wikiUrl = $"https://pt.wikipedia.org/api/rest_v1/page/summary/{Uri.EscapeDataString(cleanPrompt)}";
                string json = await _httpClient.GetStringAsync(wikiUrl);
                using var doc = JsonDocument.Parse(json);
                if (doc.RootElement.TryGetProperty("extract", out var ext) && !string.IsNullOrWhiteSpace(ext.GetString()))
                {
                    return ext.GetString()!;
                }
            }
            catch { }

            return "💡 Hmm, não consegui uma resposta ideal agora. Pode perguntar de outro jeito?";
        }

        /// <summary>
        /// Robust Math and Account Parser supporting Natural Portuguese text (e.g. "1234 vezes 4 menos 10 dividido pra 2")
        /// </summary>
        private static string? TryEvaluateMath(string text)
        {
            try
            {
                string lower = text.ToLowerInvariant().Trim();

                // 1. Percentage: "X% de Y" or "X% of Y"
                var pctMatch = Regex.Match(lower, @"(\d+(?:[.,]\d+)?)\s*%\s*(?:de|of|\*)\s*(\d+(?:[.,]\d+)?)");
                if (pctMatch.Success)
                {
                    double pct = double.Parse(pctMatch.Groups[1].Value.Replace(',', '.'), System.Globalization.CultureInfo.InvariantCulture);
                    double val = double.Parse(pctMatch.Groups[2].Value.Replace(',', '.'), System.Globalization.CultureInfo.InvariantCulture);
                    double res = (pct / 100.0) * val;
                    return $"📊 {pct}% de {val} = {res:0.##}";
                }

                // 2. Square root: "raiz de X" or "sqrt(X)"
                var sqrtMatch = Regex.Match(lower, @"(?:raiz\s*quadrada\s*de|raiz\s*de|sqrt\s*\(?)\s*(\d+(?:[.,]\d+)?)");
                if (sqrtMatch.Success)
                {
                    double val = double.Parse(sqrtMatch.Groups[1].Value.Replace(',', '.'), System.Globalization.CultureInfo.InvariantCulture);
                    double res = Math.Sqrt(val);
                    return $"📐 √{val} = {res:0.##}";
                }

                // 3. Power: "X ^ Y" or "X elevado a Y"
                var powMatch = Regex.Match(lower, @"(\d+(?:[.,]\d+)?)\s*(?:\^|elevado\s*a)\s*(\d+(?:[.,]\d+)?)");
                if (powMatch.Success)
                {
                    double b = double.Parse(powMatch.Groups[1].Value.Replace(',', '.'), System.Globalization.CultureInfo.InvariantCulture);
                    double exp = double.Parse(powMatch.Groups[2].Value.Replace(',', '.'), System.Globalization.CultureInfo.InvariantCulture);
                    double res = Math.Pow(b, exp);
                    return $"⚡ {b}^{exp} = {res:0.##}";
                }

                // 4. Translate written Portuguese operators into math symbols:
                string expr = lower;
                expr = Regex.Replace(expr, @"^(?:quanto\s*é|calcule|calcula|fazer\s*conta|qual\s*é\s*o\s*resultado\s*de|resultado\s*de|qual\s*o\s*valor\s*de|\?|=)\s*", "");
                
                expr = Regex.Replace(expr, @"\bmultiplicado\s*por\b", "*");
                expr = Regex.Replace(expr, @"\bvezes\b", "*");
                expr = Regex.Replace(expr, @"\bdividido\s*(?:por|pra|pelo|por\s*um|em)?\b", "/");
                expr = Regex.Replace(expr, @"\bmais\b", "+");
                expr = Regex.Replace(expr, @"\bsomado\s*(?:com|a)?\b", "+");
                expr = Regex.Replace(expr, @"\bmenos\b", "-");
                expr = Regex.Replace(expr, @"\bsubtra(?:[íi]|i)do\s*(?:de|por)?\b", "-");

                expr = expr.Replace("x", "*").Replace("X", "*").Replace("÷", "/").Replace(",", ".").Replace("?", "").Trim();

                if (Regex.IsMatch(expr, @"^[\d\s\+\-\*\/\(\)\.]+$") && Regex.IsMatch(expr, @"[\+\-\*\/]"))
                {
                    var table = new DataTable();
                    var computeRes = table.Compute(expr, null);
                    if (computeRes != null)
                    {
                        double finalNum = Convert.ToDouble(computeRes);
                        return $"🧮 {text} = {finalNum:0.##}";
                    }
                }
            }
            catch { }

            return null;
        }
    }
}
