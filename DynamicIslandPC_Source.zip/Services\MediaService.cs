using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;
using Windows.Media.Control;
using Windows.Storage.Streams;

namespace DynamicIsland.Services
{
    public class MediaInfo
    {
        public string Title { get; set; } = "Nenhuma mídia em reprodução";
        public string Artist { get; set; } = "DynamicIsland PC";
        public BitmapSource? AlbumArt { get; set; }
        public bool IsPlaying { get; set; }
        public bool HasMedia { get; set; }
        public bool IsSpotify { get; set; }
        public TimeSpan Position { get; set; } = TimeSpan.Zero;
        public TimeSpan EndTime { get; set; } = TimeSpan.Zero;
        public double ProgressPercent => EndTime.TotalSeconds > 0 ? Math.Clamp(Position.TotalSeconds / EndTime.TotalSeconds * 100.0, 0, 100) : 0;
    }

    public class MediaService
    {
        public event Action<MediaInfo>? OnMediaInfoChanged;

        private GlobalSystemMediaTransportControlsSessionManager? _sessionManager;
        private GlobalSystemMediaTransportControlsSession? _currentSession;
        private bool _isPlaying = false;

        public bool IsPlaying() => _isPlaying;

        public async Task InitializeAsync()
        {
            try
            {
                _sessionManager = await GlobalSystemMediaTransportControlsSessionManager.RequestAsync();
                if (_sessionManager != null)
                {
                    _sessionManager.CurrentSessionChanged += SessionManager_CurrentSessionChanged;
                    UpdateCurrentSession();
                }
            }
            catch { }
        }

        private void SessionManager_CurrentSessionChanged(GlobalSystemMediaTransportControlsSessionManager sender, CurrentSessionChangedEventArgs args)
        {
            UpdateCurrentSession();
        }

        private void UpdateCurrentSession()
        {
            if (_sessionManager == null) return;

            if (_currentSession != null)
            {
                _currentSession.MediaPropertiesChanged -= CurrentSession_MediaPropertiesChanged;
                _currentSession.PlaybackInfoChanged -= CurrentSession_PlaybackInfoChanged;
                _currentSession.TimelinePropertiesChanged -= CurrentSession_TimelinePropertiesChanged;
            }

            _currentSession = _sessionManager.GetCurrentSession();

            if (_currentSession != null)
            {
                _currentSession.MediaPropertiesChanged += CurrentSession_MediaPropertiesChanged;
                _currentSession.PlaybackInfoChanged += CurrentSession_PlaybackInfoChanged;
                _currentSession.TimelinePropertiesChanged += CurrentSession_TimelinePropertiesChanged;
            }

            _ = RefreshMediaInfoAsync();
        }

        private void CurrentSession_TimelinePropertiesChanged(GlobalSystemMediaTransportControlsSession sender, TimelinePropertiesChangedEventArgs args)
        {
            _ = RefreshMediaInfoAsync();
        }

        private void CurrentSession_PlaybackInfoChanged(GlobalSystemMediaTransportControlsSession sender, PlaybackInfoChangedEventArgs args)
        {
            _ = RefreshMediaInfoAsync();
        }

        private void CurrentSession_MediaPropertiesChanged(GlobalSystemMediaTransportControlsSession sender, MediaPropertiesChangedEventArgs args)
        {
            _ = RefreshMediaInfoAsync();
        }

        public async Task RefreshMediaInfoAsync()
        {
            var info = new MediaInfo();

            if (_currentSession != null)
            {
                try
                {
                    string appId = _currentSession.SourceAppUserModelId ?? "";
                    info.IsSpotify = appId.ToLowerInvariant().Contains("spotify");

                    var mediaProps = await _currentSession.TryGetMediaPropertiesAsync();
                    var playbackInfo = _currentSession.GetPlaybackInfo();
                    var timelineProps = _currentSession.GetTimelineProperties();

                    if (mediaProps != null)
                    {
                        info.Title = string.IsNullOrWhiteSpace(mediaProps.Title) ? "Faixa Desconhecida" : mediaProps.Title;
                        info.Artist = string.IsNullOrWhiteSpace(mediaProps.Artist) ? "Artista Desconhecido" : mediaProps.Artist;
                        info.HasMedia = true;

                        if (mediaProps.Thumbnail != null)
                        {
                            using (IRandomAccessStreamWithContentType stream = await mediaProps.Thumbnail.OpenReadAsync())
                            {
                                using (var netStream = stream.AsStreamForRead())
                                {
                                    var bitmap = new BitmapImage();
                                    bitmap.BeginInit();
                                    bitmap.CacheOption = BitmapCacheOption.OnLoad;
                                    bitmap.StreamSource = netStream;
                                    bitmap.EndInit();
                                    bitmap.Freeze();
                                    info.AlbumArt = bitmap;
                                }
                            }
                        }
                    }

                    if (playbackInfo != null)
                    {
                        info.IsPlaying = (playbackInfo.PlaybackStatus == GlobalSystemMediaTransportControlsSessionPlaybackStatus.Playing);
                        _isPlaying = info.IsPlaying;
                    }

                    if (timelineProps != null)
                    {
                        info.Position = timelineProps.Position;
                        info.EndTime = timelineProps.EndTime;
                    }
                }
                catch { }
            }

            OnMediaInfoChanged?.Invoke(info);
        }

        public async Task TogglePlayPauseAsync()
        {
            if (_currentSession != null)
            {
                try { await _currentSession.TryTogglePlayPauseAsync(); } catch { }
            }
        }

        public async Task SkipNextAsync()
        {
            if (_currentSession != null)
            {
                try { await _currentSession.TrySkipNextAsync(); } catch { }
            }
        }

        public async Task SkipPreviousAsync()
        {
            if (_currentSession != null)
            {
                try { await _currentSession.TrySkipPreviousAsync(); } catch { }
            }
        }
    }
}
