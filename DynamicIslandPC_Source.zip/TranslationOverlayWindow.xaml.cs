using System.Windows;
using KeyEventArgs = System.Windows.Input.KeyEventArgs;

namespace DynamicIsland
{
    public partial class TranslationOverlayWindow : Window
    {
        public TranslationOverlayWindow(string originalText, string translatedText)
        {
            InitializeComponent();
            TxtOriginal.Text = string.IsNullOrWhiteSpace(originalText) ? "Nenhum texto identificado na tela." : originalText;
            TxtTranslated.Text = string.IsNullOrWhiteSpace(translatedText) ? "Tradução indisponível." : translatedText;
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Escape)
            {
                Close();
            }
        }
    }
}
