using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using Microsoft.Win32;

namespace DynamicIsland.Services
{
    public class QuickAppItem
    {
        public string Name { get; set; } = string.Empty;
        public string ExecutablePath { get; set; } = string.Empty;
        public string IconEmoji { get; set; } = "🚀";
    }

    public class UserSettings
    {
        public double PositionX { get; set; } = -1;
        public double PositionY { get; set; } = -1;
        public bool IsExpanded { get; set; } = false;
        public bool AutoStartWithWindows { get; set; } = true;
        public string CustomCity { get; set; } = string.Empty;
        public double CustomLatitude { get; set; } = 0;
        public double CustomLongitude { get; set; } = 0;
        public List<QuickAppItem> QuickApps { get; set; } = new()
        {
            new QuickAppItem { Name = "Spotify", ExecutablePath = "spotify.exe", IconEmoji = "🎧" },
            new QuickAppItem { Name = "OneNote", ExecutablePath = "onenote.exe", IconEmoji = "📓" },
            new QuickAppItem { Name = "Chrome", ExecutablePath = "chrome.exe", IconEmoji = "🌐" },
            new QuickAppItem { Name = "Explorer", ExecutablePath = "explorer.exe", IconEmoji = "📁" },
            new QuickAppItem { Name = "Calculadora", ExecutablePath = "calc.exe", IconEmoji = "🧮" },
            new QuickAppItem { Name = "Terminal", ExecutablePath = "wt.exe", IconEmoji = "💻" }
        };
    }

    public class SettingsService
    {
        private static readonly string SettingsFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "DynamicIsland");

        private static readonly string SettingsFilePath = Path.Combine(SettingsFolder, "settings.json");
        private const string RunRegistryKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
        private const string AppName = "DynamicIsland";

        public static UserSettings LoadSettings()
        {
            try
            {
                if (File.Exists(SettingsFilePath))
                {
                    string json = File.ReadAllText(SettingsFilePath);
                    var settings = JsonSerializer.Deserialize<UserSettings>(json);
                    if (settings != null)
                    {
                        if (settings.QuickApps == null || settings.QuickApps.Count == 0)
                        {
                            settings.QuickApps = new UserSettings().QuickApps;
                        }
                        return settings;
                    }
                }
            }
            catch { }

            return new UserSettings();
        }

        public static void SaveSettings(UserSettings settings)
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                {
                    Directory.CreateDirectory(SettingsFolder);
                }

                string json = JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(SettingsFilePath, json);

                // Configure Windows Auto-Start
                SetAutoStart(settings.AutoStartWithWindows);
            }
            catch { }
        }

        public static void SetAutoStart(bool enable)
        {
            try
            {
                using var key = Registry.CurrentUser.OpenSubKey(RunRegistryKey, true);
                if (key == null) return;

                if (enable)
                {
                    string exePath = Environment.ProcessPath ?? "";
                    if (!string.IsNullOrEmpty(exePath))
                    {
                        key.SetValue(AppName, $"\"{exePath}\"");
                    }
                }
                else
                {
                    key.DeleteValue(AppName, false);
                }
            }
            catch { }
        }
    }
}
