using System;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Threading;
using KeyEventArgs = System.Windows.Input.KeyEventArgs;
using MouseEventArgs = System.Windows.Input.MouseEventArgs;
using MouseButtonEventArgs = System.Windows.Input.MouseButtonEventArgs;
using Point = System.Windows.Point;
using Button = System.Windows.Controls.Button;
using MessageBox = System.Windows.MessageBox;
using Brushes = System.Windows.Media.Brushes;
using Color = System.Windows.Media.Color;
using DynamicIsland.Helpers;
using DynamicIsland.Native;
using DynamicIsland.Services;

namespace DynamicIsland
{
    public partial class MainWindow : Window
    {
        private SpringAnimation? _spring;
        private bool _isExpanded = false;

        private readonly DispatcherTimer _clockTimer = new();
        private readonly DispatcherTimer _musicTimer = new();
        private readonly DispatcherTimer _marqueeTimer = new();
        private readonly DispatcherTimer _weatherTimer = new();
        private readonly DispatcherTimer _spotifySearchDebounceTimer = new();
        private readonly DispatcherTimer _volumeSyncTimer = new();

        private double _marqueeOffset = 0;
        private bool _isVolumeSyncing = false;
        private readonly MediaPlayer _previewPlayer = new();

        private readonly MediaService _mediaService = new();
        private readonly TelemetryCollector _telemetryCollector = new();
        private readonly ScreenRecordService _recordService = new();
        private UserSettings _userSettings = new();

        private string _selectedConverterFile = string.Empty;

        public MainWindow()
        {
            InitializeComponent();
            InitTimers();
        }

        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Win32Api.SetupTransparentWindow(this);
            AudioDeviceManager.Initialize();

            _userSettings = SettingsService.LoadSettings();
            if (_userSettings.PositionX >= 0 && _userSettings.PositionY >= 0)
            {
                Left = _userSettings.PositionX;
                Top = _userSettings.PositionY;
            }
            else
            {
                Left = (SystemParameters.PrimaryScreenWidth - Width) / 2;
                Top = 15;
            }

            // Sync AutoStart Checkbox state
            ChkAutoStart.IsChecked = _userSettings.AutoStartWithWindows;

            // Animate IslandBorder width & height directly for super smooth center-expansion
            _spring = new SpringAnimation(IslandBorder.Width, IslandBorder.Height, UpdatePillDimensions);

            _telemetryCollector.OnTelemetryUpdated += TelemetryCollector_OnTelemetryUpdated;
            _telemetryCollector.Start();

            _mediaService.OnMediaInfoChanged += MediaService_OnMediaInfoChanged;
            await _mediaService.InitializeAsync();

            _recordService.OnRecordingStateChanged += RecordService_OnRecordingStateChanged;

            // Load Quick Apps list into UI
            QuickAppsItemsControl.ItemsSource = _userSettings.QuickApps;

            // Initialize Converter dropdown
            ConvertTargetFormatCombo.ItemsSource = new string[] { ".jpg", ".png", ".pdf", ".docx", ".txt", ".html", ".csv", ".bmp" };
            ConvertTargetFormatCombo.SelectedIndex = 0;

            // Load initial weather
            _ = UpdateWeatherAsync();

            UsnJournalSearch.InitializeFastIndex();
        }

        private void InitTimers()
        {
            // Clock animation
            _clockTimer.Interval = TimeSpan.FromMilliseconds(500);
            _clockTimer.Tick += (s, e) =>
            {
                CompactClockText.Text = DateTime.Now.ToString("HH:mm");
            };
            _clockTimer.Start();

            // Marquee
            _marqueeTimer.Interval = TimeSpan.FromMilliseconds(40);
            _marqueeTimer.Tick += (s, e) =>
            {
                _marqueeOffset -= 1.5;
                if (_marqueeOffset < -260) _marqueeOffset = 180;
                Canvas.SetLeft(MarqueeText, _marqueeOffset);
            };
            _marqueeTimer.Start();

            // Marquee
            _marqueeTimer.Interval = TimeSpan.FromMilliseconds(40);
            _marqueeTimer.Tick += (s, e) =>
            {
                _marqueeOffset -= 1.5;
                if (_marqueeOffset < -260) _marqueeOffset = 180;
                Canvas.SetLeft(MarqueeText, _marqueeOffset);
            };
            _marqueeTimer.Start();

            // Weather refresh every 20 minutes
            _weatherTimer.Interval = TimeSpan.FromMinutes(20);
            _weatherTimer.Tick += async (s, e) => await UpdateWeatherAsync();
            _weatherTimer.Start();

            // Spotify In-Island Search Debounce Timer
            _spotifySearchDebounceTimer.Interval = TimeSpan.FromMilliseconds(300);
            _spotifySearchDebounceTimer.Tick += async (s, e) =>
            {
                _spotifySearchDebounceTimer.Stop();
                await FetchSpotifySuggestionsAsync();
            };

            // Volume Synchronization Timer
            _volumeSyncTimer.Interval = TimeSpan.FromMilliseconds(200);
            _volumeSyncTimer.Tick += (s, e) =>
            {
                float currentVol = AudioDeviceManager.GetVolume();
                double sliderVal = currentVol * 100;
                if (Math.Abs(VolumeSlider.Value - sliderVal) > 1.5)
                {
                    _isVolumeSyncing = true;
                    VolumeSlider.Value = sliderVal;
                    _isVolumeSyncing = false;
                }
                if (VolumePercentText != null)
                {
                    VolumePercentText.Text = $"{(int)(currentVol * 100)}%";
                }
            };
            _volumeSyncTimer.Start();
        }

        private async System.Threading.Tasks.Task UpdateWeatherAsync()
        {
            try
            {
                var weather = await WeatherService.GetWeatherAsync(_userSettings.CustomCity, _userSettings.CustomLatitude, _userSettings.CustomLongitude);
                Dispatcher.Invoke(() =>
                {
                    WeatherIconText.Text = weather.WeatherCodeIcon;
                    WeatherCityText.Text = weather.City;
                    WeatherTempText.Text = $"{weather.Temperature:0}°";
                    WeatherConditionText.Text = weather.Condition;
                });
            }
            catch { }
        }

        private void UpdatePillDimensions(double currentWidth, double currentHeight)
        {
            // Center expansion: IslandBorder expands symmetrically from center within RootCanvas
            IslandBorder.Width = currentWidth;
            IslandBorder.Height = currentHeight;
            IslandBorder.CornerRadius = new CornerRadius(_isExpanded ? 24 : 21);
        }

        private void Window_MouseEnter(object sender, MouseEventArgs e)
        {
            // Hover expansion disabled - expands via double-click as requested
        }

        private void Window_MouseLeave(object sender, MouseEventArgs e)
        {
        }

        private void Window_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            SetExpandedState(!_isExpanded);
        }

        private void BtnCollapse_Click(object sender, RoutedEventArgs e)
        {
            SetExpandedState(false);
        }

        private void SetExpandedState(bool expand)
        {
            if (_isExpanded == expand) return;
            _isExpanded = expand;

            if (_isExpanded)
            {
                CompactView.Visibility = Visibility.Collapsed;
                ExpandedView.Visibility = Visibility.Visible;
                AdaptiveBackgroundGrid.Opacity = 0.85;
                _spring?.SetTarget(580, 205);
            }
            else
            {
                ExpandedView.Visibility = Visibility.Collapsed;
                CompactView.Visibility = Visibility.Visible;
                AdaptiveBackgroundGrid.Opacity = 0.0;
                SpotifySuggestionsScrollViewer.Visibility = Visibility.Collapsed;
                SpotifySuggestionsItemsControl.ItemsSource = null;
                _spring?.SetTarget(340, 42);
            }
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                Win32Api.DragWindow(this);
                SavePosition();
            }
        }

        private void SavePosition()
        {
            _userSettings.PositionX = Left;
            _userSettings.PositionY = Top;
            SettingsService.SaveSettings(_userSettings);
        }

        #region Tab Navigation
        private void TabMedia_Click(object sender, RoutedEventArgs e)
        {
            SwitchTab(PageMedia);
            if (_isExpanded) _spring?.SetTarget(580, SpotifySuggestionsScrollViewer.Visibility == Visibility.Visible ? 290 : 205);
        }

        private void TabAi_Click(object sender, RoutedEventArgs e)
        {
            SwitchTab(PageAi);
            if (_isExpanded) _spring?.SetTarget(580, 230);
        }

        private void TabTranslate_Click(object sender, RoutedEventArgs e)
        {
            SwitchTab(PageTranslate);
            if (_isExpanded) _spring?.SetTarget(580, 220);
        }

        private void TabSearch_Click(object sender, RoutedEventArgs e)
        {
            SwitchTab(PageSearch);
            if (_isExpanded) _spring?.SetTarget(580, 205);
        }

        private void TabConvert_Click(object sender, RoutedEventArgs e)
        {
            SwitchTab(PageConvert);
            if (_isExpanded) _spring?.SetTarget(580, 205);
        }

        private void TabApps_Click(object sender, RoutedEventArgs e)
        {
            SwitchTab(PageApps);
            if (_isExpanded) _spring?.SetTarget(580, 205);
        }

        private void TabTools_Click(object sender, RoutedEventArgs e)
        {
            SwitchTab(PageTools);
            if (_isExpanded) _spring?.SetTarget(580, 205);
            _ = UpdateWeatherAsync();
        }

        private void SwitchTab(Grid activePage)
        {
            PageMedia.Visibility = Visibility.Collapsed;
            PageAi.Visibility = Visibility.Collapsed;
            PageTranslate.Visibility = Visibility.Collapsed;
            PageSearch.Visibility = Visibility.Collapsed;
            PageConvert.Visibility = Visibility.Collapsed;
            PageApps.Visibility = Visibility.Collapsed;
            PageTools.Visibility = Visibility.Collapsed;

            activePage.Visibility = Visibility.Visible;
        }
        #endregion

        #region Media Callbacks & Controls
        private void MediaService_OnMediaInfoChanged(MediaInfo info)
        {
            Dispatcher.Invoke(() =>
            {
                string fullTrackStr = $"{info.Title} • {info.Artist}";
                MarqueeText.Text = fullTrackStr;

                ExpandedTitleText.Text = info.Title;
                ExpandedArtistText.Text = info.Artist;

                // Toggle Spotify search box container visibility
                SpotifySearchBoxContainer.Visibility = info.IsSpotify ? Visibility.Visible : Visibility.Collapsed;

                // Update album art in both compact & expanded view
                if (info.AlbumArt != null)
                {
                    AlbumCoverImage.Source = info.AlbumArt;
                    CompactAlbumArt.Source = info.AlbumArt;
                    CompactAlbumArt.Visibility = Visibility.Visible;
                    CompactClockEmoji.Visibility = Visibility.Collapsed;
                    DefaultAlbumIcon.Visibility = Visibility.Collapsed;

                    Color dominant = ColorExtractor.ExtractDominantColor(info.AlbumArt);
                    GradientColorStart.Color = Color.FromArgb(120, dominant.R, dominant.G, dominant.B);
                    IslandBorder.BorderBrush = new SolidColorBrush(Color.FromArgb(180, dominant.R, dominant.G, dominant.B));
                }
                else
                {
                    AlbumCoverImage.Source = null;
                    CompactAlbumArt.Source = null;
                    CompactAlbumArt.Visibility = Visibility.Collapsed;
                    CompactClockEmoji.Visibility = Visibility.Visible;
                    DefaultAlbumIcon.Visibility = Visibility.Visible;
                    GradientColorStart.Color = Color.FromArgb(50, 168, 85, 247);
                    IslandBorder.BorderBrush = new SolidColorBrush(Color.FromArgb(90, 168, 85, 247));
                }

                // Progress Bar & Time
                SongProgressBar.Value = info.ProgressPercent;
                CurrentTimeText.Text = info.Position.ToString(@"m\:ss");
                TimeSpan remaining = info.EndTime - info.Position;
                RemainingTimeText.Text = (remaining.TotalSeconds > 0 ? "-" : "") + remaining.ToString(@"m\:ss");

                // Play / Pause Icon
                if (info.IsPlaying)
                {
                    PlayPauseIcon.Data = Geometry.Parse("M6,19h4V5H6v14zm8-14v14h4V5h-4z");
                }
                else
                {
                    PlayPauseIcon.Data = Geometry.Parse("M8,5v14l11-7z");
                }
            });
        }

        private async void BtnPlayPause_Click(object sender, RoutedEventArgs e) => await _mediaService.TogglePlayPauseAsync();
        private async void BtnPrev_Click(object sender, RoutedEventArgs e) => await _mediaService.SkipPreviousAsync();
        private async void BtnNext_Click(object sender, RoutedEventArgs e) => await _mediaService.SkipNextAsync();

        private void BtnVolDown_Click(object sender, RoutedEventArgs e)
        {
            float current = AudioDeviceManager.GetVolume();
            AudioDeviceManager.SetVolume(Math.Max(0f, current - 0.05f));
        }

        private void BtnVolUp_Click(object sender, RoutedEventArgs e)
        {
            float current = AudioDeviceManager.GetVolume();
            AudioDeviceManager.SetVolume(Math.Min(1f, current + 0.05f));
        }

        private void VolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (VolumePercentText != null)
            {
                VolumePercentText.Text = $"{(int)e.NewValue}%";
            }
            if (!_isVolumeSyncing)
            {
                AudioDeviceManager.SetVolume((float)(e.NewValue / 100.0));
            }
        }

        private void SpotifySearchInput_TextChanged(object sender, TextChangedEventArgs e)
        {
            _spotifySearchDebounceTimer.Stop();
            _spotifySearchDebounceTimer.Start();
        }

        private async System.Threading.Tasks.Task FetchSpotifySuggestionsAsync()
        {
            string query = SpotifySearchInput.Text.Trim();
            if (string.IsNullOrWhiteSpace(query))
            {
                SpotifySuggestionsScrollViewer.Visibility = Visibility.Collapsed;
                SpotifySuggestionsItemsControl.ItemsSource = null;
                if (_isExpanded && PageMedia.Visibility == Visibility.Visible)
                {
                    _spring?.SetTarget(580, 205);
                }
                return;
            }

            var tracks = await MusicSearchService.SearchTracksAsync(query, 6);
            if (tracks.Count > 0)
            {
                SpotifySuggestionsItemsControl.ItemsSource = tracks;
                SpotifySuggestionsScrollViewer.Visibility = Visibility.Visible;
                if (_isExpanded && PageMedia.Visibility == Visibility.Visible)
                {
                    _spring?.SetTarget(580, 290);
                }
            }
            else
            {
                SpotifySuggestionsScrollViewer.Visibility = Visibility.Collapsed;
                if (_isExpanded && PageMedia.Visibility == Visibility.Visible)
                {
                    _spring?.SetTarget(580, 205);
                }
            }
        }

        private void SpotifySuggestionItem_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.DataContext is MusicTrackSuggestion item)
            {
                try
                {
                    if (!string.IsNullOrWhiteSpace(item.PreviewUrl))
                    {
                        _previewPlayer.Open(new Uri(item.PreviewUrl));
                        _previewPlayer.Play();
                    }

                    string uri = $"spotify:search:{Uri.EscapeDataString(item.SearchTerm)}";
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = uri,
                        UseShellExecute = true
                    });
                }
                catch
                {
                    try
                    {
                        Process.Start(new ProcessStartInfo
                        {
                            FileName = $"https://open.spotify.com/search/{Uri.EscapeDataString(item.SearchTerm)}",
                            UseShellExecute = true
                        });
                    }
                    catch { }
                }

                SpotifySearchInput.Text = "";
                SpotifySuggestionsScrollViewer.Visibility = Visibility.Collapsed;
                SpotifySuggestionsItemsControl.ItemsSource = null;
                if (_isExpanded && PageMedia.Visibility == Visibility.Visible)
                {
                    _spring?.SetTarget(580, 205);
                }
            }
        }

        private void SpotifySearchInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                ExecuteSpotifySearch();
            }
        }

        private void BtnSpotifySearch_Click(object sender, RoutedEventArgs e)
        {
            ExecuteSpotifySearch();
        }

        private void ExecuteSpotifySearch()
        {
            string query = SpotifySearchInput.Text.Trim();
            if (string.IsNullOrWhiteSpace(query)) return;

            try
            {
                string uri = $"spotify:search:{Uri.EscapeDataString(query)}";
                Process.Start(new ProcessStartInfo
                {
                    FileName = uri,
                    UseShellExecute = true
                });
            }
            catch
            {
                try
                {
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = $"https://open.spotify.com/search/{Uri.EscapeDataString(query)}",
                        UseShellExecute = true
                    });
                }
                catch { }
            }
        }
        #endregion

        #region AI Chat Assistant
        private void AiQuestionInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                BtnAskAi_Click(sender, e);
            }
        }

        private async void BtnAskAi_Click(object sender, RoutedEventArgs e)
        {
            string question = AiQuestionInput.Text.Trim();
            if (string.IsNullOrWhiteSpace(question)) return;

            AiResponseText.Text = "🤔 Pensando...";
            var answer = await AiChatService.AskAiAsync(question);
            AiResponseText.Text = answer;
        }
        #endregion

        #region Screen Translator
        private async void BtnTranslateScreen_Click(object sender, RoutedEventArgs e)
        {
            TranslateResultText.Text = "Selecione a área para tradução...";

            // 1. Show Selection Window to pick an area
            var selectionWin = new SelectionWindow();
            bool? result = selectionWin.ShowDialog();

            System.Drawing.Rectangle? selectedArea = null;
            if (result == true)
            {
                selectedArea = selectionWin.SelectedArea;
            }
            else
            {
                // User cancelled selection
                TranslateResultText.Text = "Seleção cancelada.";
                return;
            }

            TranslateResultText.Text = "Capturando área e executando OCR...";

            string targetLang = "pt";
            if (TranslateLangCombo.SelectedItem is ComboBoxItem item && item.Tag is string tag)
            {
                targetLang = tag;
            }

            var (ocr, translated) = await ScreenTranslateService.CaptureAndTranslateAsync(targetLang, selectedArea);

            // No longer updating TranslateResultText here to avoid redundant "pre-visualization"
            // in the main window before the overlay appears.

            // Open overlay window in front of current screen
            try
            {
                var overlay = new TranslationOverlayWindow(ocr, translated);
                overlay.Show();
            }
            catch { }
        }
        #endregion

        #region Search (Lupa)
        private void GlobalSearchInput_TextChanged(object sender, TextChangedEventArgs e)
        {
            string query = GlobalSearchInput.Text.Trim();
            if (string.IsNullOrWhiteSpace(query))
            {
                GlobalSearchResultsList.ItemsSource = null;
                return;
            }

            var results = UsnJournalSearch.Search(query, 12);
            GlobalSearchResultsList.ItemsSource = results;
        }

        private void GlobalSearchResultsList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (GlobalSearchResultsList.SelectedItem is SearchResultItem selected)
            {
                try
                {
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = selected.FullPath,
                        UseShellExecute = true
                    });
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Não foi possível abrir o arquivo/app: {ex.Message}", "DynamicIsland PC", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
        }
        #endregion

        #region File Converter
        private void BtnPickFileToConvert_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Title = "Selecione o arquivo para converter",
                Filter = "Todos os Arquivos Suportados|*.docx;*.pdf;*.jpg;*.jpeg;*.png;*.bmp;*.txt;*.csv;*.md;*.log|PDF (*.pdf)|*.pdf|Documentos Word (*.docx)|*.docx|Imagens (*.jpg;*.png;*.bmp)|*.jpg;*.png;*.bmp|Texto (*.txt;*.csv;*.md)|*.txt;*.csv;*.md|Todos os Arquivos (*.*)|*.*"
            };

            if (dialog.ShowDialog() == true)
            {
                _selectedConverterFile = dialog.FileName;
                ConvertSelectedFileText.Text = Path.GetFileName(_selectedConverterFile);
                ConvertStatusMessage.Text = "";
            }
        }

        private async void BtnExecuteConvert_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_selectedConverterFile) || !File.Exists(_selectedConverterFile))
            {
                MessageBox.Show("Por favor, selecione um arquivo primeiro!", "Conversor de Arquivos", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            string targetFormat = ConvertTargetFormatCombo.SelectedItem?.ToString() ?? ".pdf";
            ConvertStatusMessage.Foreground = Brushes.LightSkyBlue;
            ConvertStatusMessage.Text = "Convertendo arquivo, aguarde...";

            var result = await FileConverterService.ConvertAsync(_selectedConverterFile, targetFormat);

            if (result.Success)
            {
                ConvertStatusMessage.Foreground = new SolidColorBrush(Color.FromRgb(52, 211, 153));
                ConvertStatusMessage.Text = "✔ " + result.Message;

                try
                {
                    Process.Start("explorer.exe", $"/select,\"{result.OutputPath}\"");
                }
                catch { }
            }
            else
            {
                ConvertStatusMessage.Foreground = new SolidColorBrush(Color.FromRgb(248, 113, 113));
                ConvertStatusMessage.Text = "✖ " + result.Message;
            }
        }
        #endregion

        #region Telemetry Callbacks
        private void TelemetryCollector_OnTelemetryUpdated(SystemTelemetryData data)
        {
            Dispatcher.Invoke(() =>
            {
                CompactBatteryText.Text = $"{data.BatteryPercent}%";

                CpuText.Text = $"{data.CpuUsagePercent}%";
                CpuProgress.Value = data.CpuUsagePercent;

                BatteryText.Text = $"{data.BatteryPercent}%";
                BatteryProgress.Value = data.BatteryPercent;
            });
        }
        #endregion

        #region Screen Recording
        private void BtnRecordToggle_Click(object sender, RoutedEventArgs e)
        {
            _recordService.ToggleRecording();
        }

        private void RecordService_OnRecordingStateChanged(bool isRecording)
        {
            Dispatcher.Invoke(() =>
            {
                if (isRecording)
                {
                    CompactRecDot.Visibility = Visibility.Visible;
                    RecStatusText.Text = "Gravando Vídeo...";
                    RecSubtext.Text = "Clique para alternar";
                    BtnRecordToggle.Background = new SolidColorBrush(Color.FromRgb(220, 38, 38));
                }
                else
                {
                    CompactRecDot.Visibility = Visibility.Collapsed;
                    RecStatusText.Text = "Gravação de Vídeo";
                    RecSubtext.Text = "Clique para iniciar";
                    BtnRecordToggle.Background = new SolidColorBrush(Color.FromRgb(239, 68, 68));
                }
            });
        }
        #endregion

        #region Auto-start Checkbox
        private void ChkAutoStart_Checked(object sender, RoutedEventArgs e)
        {
            _userSettings.AutoStartWithWindows = true;
            SettingsService.SaveSettings(_userSettings);
        }

        private void ChkAutoStart_Unchecked(object sender, RoutedEventArgs e)
        {
            _userSettings.AutoStartWithWindows = false;
            SettingsService.SaveSettings(_userSettings);
        }
        #endregion

        #region Quick Apps Launch
        private void QuickApp_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is string exePath)
            {
                try
                {
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = exePath,
                        UseShellExecute = true
                    });
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Não foi possível abrir o app: {ex.Message}", "DynamicIsland PC", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
        }

        private void BtnAddApp_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dialog = new Microsoft.Win32.OpenFileDialog
                {
                    Title = "Selecione o Aplicativo ou Atalho",
                    Filter = "Aplicativos e Atalhos (*.exe;*.lnk)|*.exe;*.lnk|Todos os Arquivos (*.*)|*.*",
                    CheckFileExists = true
                };

                if (dialog.ShowDialog() == true)
                {
                    string filePath = dialog.FileName;
                    string fileName = System.IO.Path.GetFileNameWithoutExtension(filePath);

                    var newApp = new QuickAppItem
                    {
                        Name = fileName,
                        ExecutablePath = filePath,
                        IconEmoji = "⭐"
                    };

                    _userSettings.QuickApps.Add(newApp);
                    SettingsService.SaveSettings(_userSettings);

                    QuickAppsItemsControl.ItemsSource = null;
                    QuickAppsItemsControl.ItemsSource = _userSettings.QuickApps;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao adicionar aplicativo: {ex.Message}", "DynamicIsland PC", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private async void BtnChangeCity_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string prompt = "Digite o nome da sua cidade (ex: São Paulo, Rio de Janeiro, Curitiba, Lisboa):";
                string input = Microsoft.VisualBasic.Interaction.InputBox(prompt, "Alterar Localização do Clima", _userSettings.CustomCity);

                if (!string.IsNullOrWhiteSpace(input))
                {
                    _userSettings.CustomCity = input.Trim();
                    _userSettings.CustomLatitude = 0;
                    _userSettings.CustomLongitude = 0;
                    SettingsService.SaveSettings(_userSettings);
                    await UpdateWeatherAsync();
                }
            }
            catch { }
        }
        #endregion

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            Close();
            System.Windows.Application.Current.Shutdown();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            _telemetryCollector.Stop();
            _spring?.Stop();
            _recordService.StopRecording();
            SavePosition();
        }
    }
}
