using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

namespace DynamicIsland.Services
{
    public class MusicTrackSuggestion
    {
        public string Title { get; set; } = string.Empty;
        public string Artist { get; set; } = string.Empty;
        public string Album { get; set; } = string.Empty;
        public string CoverUrl { get; set; } = string.Empty;
        public string PreviewUrl { get; set; } = string.Empty;
        public string SearchTerm => $"{Title} {Artist}";
    }

    public static class MusicSearchService
    {
        private static readonly HttpClient _http = new HttpClient { Timeout = TimeSpan.FromSeconds(4) };

        public static async Task<List<MusicTrackSuggestion>> SearchTracksAsync(string query, int limit = 6)
        {
            var list = new List<MusicTrackSuggestion>();
            if (string.IsNullOrWhiteSpace(query)) return list;

            try
            {
                string url = $"https://api.deezer.com/search?q={Uri.EscapeDataString(query)}&limit={limit}";
                string json = await _http.GetStringAsync(url);
                using var doc = JsonDocument.Parse(json);
                if (doc.RootElement.TryGetProperty("data", out var data) && data.ValueKind == JsonValueKind.Array)
                {
                    foreach (var item in data.EnumerateArray())
                    {
                        var track = new MusicTrackSuggestion();
                        if (item.TryGetProperty("title", out var t)) track.Title = t.GetString() ?? "";
                        if (item.TryGetProperty("artist", out var art) && art.TryGetProperty("name", out var aName))
                        {
                            track.Artist = aName.GetString() ?? "";
                        }
                        if (item.TryGetProperty("album", out var alb))
                        {
                            if (alb.TryGetProperty("title", out var albTitle)) track.Album = albTitle.GetString() ?? "";
                            if (alb.TryGetProperty("cover_small", out var cov)) track.CoverUrl = cov.GetString() ?? "";
                        }
                        if (item.TryGetProperty("preview", out var prev)) track.PreviewUrl = prev.GetString() ?? "";

                        list.Add(track);
                    }
                }
            }
            catch { }

            return list;
        }
    }
}
