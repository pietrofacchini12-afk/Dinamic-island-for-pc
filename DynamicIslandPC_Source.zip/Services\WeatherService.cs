using System;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

namespace DynamicIsland.Services
{
    public class WeatherData
    {
        public double Temperature { get; set; } = 22.0;
        public double TempMin { get; set; } = 18.0;
        public double TempMax { get; set; } = 26.0;
        public string Condition { get; set; } = "Ensolarado";
        public string WeatherCodeIcon { get; set; } = "☀️";
        public string City { get; set; } = "Local";
    }

    public class WeatherService
    {
        private static readonly HttpClient _httpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(6) };

        public static async Task<WeatherData> GetWeatherAsync(string customCity = "", double customLat = 0, double customLon = 0)
        {
            var data = new WeatherData();
            try
            {
                double latitude = customLat;
                double longitude = customLon;
                string city = customCity;

                // 1. If user set a custom city, geocode it
                if (!string.IsNullOrWhiteSpace(customCity) && (latitude == 0 && longitude == 0))
                {
                    try
                    {
                        string geoUrl = $"https://geocoding-api.open-meteo.com/v1/search?name={Uri.EscapeDataString(customCity)}&count=1&language=pt&format=json";
                        var geoResp = await _httpClient.GetStringAsync(geoUrl);
                        using var gDoc = JsonDocument.Parse(geoResp);
                        if (gDoc.RootElement.TryGetProperty("results", out var results) && results.GetArrayLength() > 0)
                        {
                            var first = results[0];
                            latitude = first.GetProperty("latitude").GetDouble();
                            longitude = first.GetProperty("longitude").GetDouble();
                            city = first.GetProperty("name").GetString() ?? customCity;
                        }
                    }
                    catch { }
                }

                // 2. Auto-detect real user location by IP
                if (latitude == 0 && longitude == 0)
                {
                    // Provider A: ipapi.co (precise European/Swiss & Global geolocation)
                    try
                    {
                        var ipJson = await _httpClient.GetStringAsync("https://ipapi.co/json/");
                        using var ipApiDoc = JsonDocument.Parse(ipJson);
                        var root = ipApiDoc.RootElement;
                        if (root.TryGetProperty("latitude", out var latProp) && root.TryGetProperty("longitude", out var lonProp))
                        {
                            latitude = latProp.GetDouble();
                            longitude = lonProp.GetDouble();
                            city = root.GetProperty("city").GetString() ?? "Local";
                        }
                    }
                    catch { }

                    // Provider B fallback: ipwho.is
                    if (latitude == 0 && longitude == 0)
                    {
                        try
                        {
                            var ipWhoJson = await _httpClient.GetStringAsync("https://ipwho.is/");
                            using var whoDoc = JsonDocument.Parse(ipWhoJson);
                            var root = whoDoc.RootElement;
                            if (root.TryGetProperty("success", out var s) && s.GetBoolean())
                            {
                                latitude = root.GetProperty("latitude").GetDouble();
                                longitude = root.GetProperty("longitude").GetDouble();
                                city = root.GetProperty("city").GetString() ?? "Local";
                            }
                        }
                        catch { }
                    }

                    // Provider C fallback: ip-api.com
                    if (latitude == 0 && longitude == 0)
                    {
                        try
                        {
                            var geoJson = await _httpClient.GetStringAsync("http://ip-api.com/json/?fields=status,city,lat,lon");
                            using var geoDoc = JsonDocument.Parse(geoJson);
                            var root = geoDoc.RootElement;
                            if (root.GetProperty("status").GetString() == "success")
                            {
                                latitude = root.GetProperty("lat").GetDouble();
                                longitude = root.GetProperty("lon").GetDouble();
                                city = root.GetProperty("city").GetString() ?? "Local";
                            }
                        }
                        catch { }
                    }
                }

                // If completely failed, default gracefully
                if (latitude == 0 && longitude == 0)
                {
                    latitude = 47.37;
                    longitude = 8.54;
                    city = "Zurich";
                }

                data.City = city;

                // Query Open-Meteo for accurate forecast
                string url = $"https://api.open-meteo.com/v1/forecast?latitude={latitude.ToString(System.Globalization.CultureInfo.InvariantCulture)}&longitude={longitude.ToString(System.Globalization.CultureInfo.InvariantCulture)}&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min&timezone=auto";
                var weatherJson = await _httpClient.GetStringAsync(url);
                using var weatherDoc = JsonDocument.Parse(weatherJson);
                var wRoot = weatherDoc.RootElement;

                if (wRoot.TryGetProperty("current", out var current))
                {
                    data.Temperature = Math.Round(current.GetProperty("temperature_2m").GetDouble(), 1);
                    int code = current.GetProperty("weather_code").GetInt32();
                    MapWeatherCode(code, data);
                }

                if (wRoot.TryGetProperty("daily", out var daily))
                {
                    var maxList = daily.GetProperty("temperature_2m_max");
                    var minList = daily.GetProperty("temperature_2m_min");
                    if (maxList.GetArrayLength() > 0) data.TempMax = Math.Round(maxList[0].GetDouble(), 1);
                    if (minList.GetArrayLength() > 0) data.TempMin = Math.Round(minList[0].GetDouble(), 1);
                }
            }
            catch
            {
                data.Condition = "Parcialmente Nublado";
                data.WeatherCodeIcon = "⛅";
                data.Temperature = 20.0;
                data.TempMin = 14.0;
                data.TempMax = 22.0;
            }

            return data;
        }

        private static void MapWeatherCode(int code, WeatherData data)
        {
            switch (code)
            {
                case 0:
                    data.Condition = "Céu Limpo";
                    data.WeatherCodeIcon = "☀️";
                    break;
                case 1:
                case 2:
                    data.Condition = "Parcialmente Nublado";
                    data.WeatherCodeIcon = "⛅";
                    break;
                case 3:
                    data.Condition = "Nublado";
                    data.WeatherCodeIcon = "☁️";
                    break;
                case 45:
                case 48:
                    data.Condition = "Nevoeiro";
                    data.WeatherCodeIcon = "🌫️";
                    break;
                case 51:
                case 53:
                case 55:
                case 61:
                case 63:
                case 65:
                case 80:
                case 81:
                case 82:
                    data.Condition = "Chuva";
                    data.WeatherCodeIcon = "🌧️";
                    break;
                case 71:
                case 73:
                case 75:
                    data.Condition = "Neve";
                    data.WeatherCodeIcon = "❄️";
                    break;
                case 95:
                case 96:
                case 99:
                    data.Condition = "Tempestade";
                    data.WeatherCodeIcon = "⛈️";
                    break;
                default:
                    data.Condition = "Tempo Bom";
                    data.WeatherCodeIcon = "🌤️";
                    break;
            }
        }
    }
}
