using System;
using System.Drawing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace DynamicIsland
{
    public partial class SelectionWindow : Window
    {
        private System.Windows.Point _startPoint;
        private bool _isDragging = false;
        public Rectangle? SelectedArea { get; private set; }

        public SelectionWindow()
        {
            InitializeComponent();
            this.MouseDown += SelectionWindow_MouseDown;
            this.MouseMove += SelectionWindow_MouseMove;
            this.MouseUp += SelectionWindow_MouseUp;
        }

        private void SelectionWindow_MouseDown(object sender, MouseButtonEventArgs e)
        {
            _isDragging = true;
            _startPoint = e.GetPosition(SelectionCanvas);

            Canvas.SetLeft(SelectionRectangle, _startPoint.X);
            Canvas.SetTop(SelectionRectangle, _startPoint.Y);
            SelectionRectangle.Width = 0;
            SelectionRectangle.Height = 0;
        }

        private void SelectionWindow_MouseMove(object sender, System.Windows.Input.MouseEventArgs e)
        {
            if (!_isDragging) return;

            System.Windows.Point currentPoint = e.GetPosition(SelectionCanvas);

            double x = Math.Min(_startPoint.X, currentPoint.X);
            double y = Math.Min(_startPoint.Y, currentPoint.Y);
            double width = Math.Abs(_startPoint.X - currentPoint.X);
            double height = Math.Abs(_startPoint.Y - currentPoint.Y);

            Canvas.SetLeft(SelectionRectangle, x);
            Canvas.SetTop(SelectionRectangle, y);
            SelectionRectangle.Width = width;
            SelectionRectangle.Height = height;
        }

        private void SelectionWindow_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (!_isDragging) return;
            _isDragging = false;

            System.Windows.Point endPoint = e.GetPosition(SelectionCanvas);

            int x = (int)Math.Min(_startPoint.X, endPoint.X);
            int y = (int)Math.Min(_startPoint.Y, endPoint.Y);
            int width = (int)Math.Abs(_startPoint.X - endPoint.X);
            int height = (int)Math.Abs(_startPoint.Y - endPoint.Y);

            if (width > 5 && height > 5)
            {
                SelectedArea = new Rectangle(x, y, width, height);
            }

            this.DialogResult = true;
            this.Close();
        }
    }
}
