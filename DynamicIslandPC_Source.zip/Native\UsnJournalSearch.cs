using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace DynamicIsland.Native
{
    public class SearchResultItem
    {
        public string Name { get; set; } = string.Empty;
        public string FullPath { get; set; } = string.Empty;
        public bool IsDirectory { get; set; }
    }

    public class UsnJournalSearch
    {
        private static readonly ConcurrentBag<SearchResultItem> _fastCache = new();
        private static bool _isIndexed = false;
        private static readonly object _indexLock = new();

        public static void InitializeFastIndex()
        {
            if (_isIndexed) return;

            Task.Run(() =>
            {
                lock (_indexLock)
                {
                    if (_isIndexed) return;
                    try
                    {
                        FastScanFallback();
                    }
                    catch { }
                    finally
                    {
                        _isIndexed = true;
                    }
                }
            });
        }

        private static void FastScanFallback()
        {
            string userProfile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            string[] scanPaths = new[]
            {
                Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                Path.Combine(userProfile, "Downloads"),
                Path.Combine(userProfile, "Videos"),
                Path.Combine(userProfile, "Pictures")
            };

            Parallel.ForEach(scanPaths, path =>
            {
                if (!Directory.Exists(path)) return;
                try
                {
                    var options = new EnumerationOptions
                    {
                        RecurseSubdirectories = true,
                        IgnoreInaccessible = true,
                        MaxRecursionDepth = 5
                    };

                    foreach (var entry in Directory.EnumerateFileSystemEntries(path, "*", options))
                    {
                        _fastCache.Add(new SearchResultItem
                        {
                            Name = Path.GetFileName(entry),
                            FullPath = entry,
                            IsDirectory = Directory.Exists(entry)
                        });

                        if (_fastCache.Count >= 10000) break;
                    }
                }
                catch { }
            });
        }

        public static List<SearchResultItem> Search(string query, int maxResults = 8)
        {
            if (string.IsNullOrWhiteSpace(query)) return new List<SearchResultItem>();

            InitializeFastIndex();
            string searchPattern = query.Trim().ToLowerInvariant();

            return _fastCache
                .Where(x => x.Name.ToLowerInvariant().Contains(searchPattern))
                .Take(maxResults)
                .ToList();
        }
    }
}
