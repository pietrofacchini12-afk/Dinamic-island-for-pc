using System;
using System.Runtime.InteropServices;
using DynamicIsland.Native;

namespace DynamicIsland.Native
{
    public static class AudioDeviceManager
    {
        private static IAudioEndpointVolume? _volumeControl;

        public static void Initialize()
        {
            try
            {
                var enumerator = new MMDeviceEnumerator();
                IMMDeviceEnumerator deviceEnumerator = (IMMDeviceEnumerator)enumerator;

                deviceEnumerator.GetDefaultAudioEndpoint(0, 0, out var device);

                var guid = new Guid("5CDF2C82-841E-4546-9722-0CF740D8FF35"); // IAudioEndpointVolume
                device.Activate(ref guid, 1, IntPtr.Zero, out var volumeInterface);

                _volumeControl = (IAudioEndpointVolume)volumeInterface;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"AudioDeviceManager Init Error: {ex.Message}");
            }
        }

        public static float GetVolume()
        {
            if (_volumeControl == null) return 0;
            _volumeControl.GetMasterVolumeLevelScalar(out float volume);
            return volume;
        }

        public static void SetVolume(float volume)
        {
            if (_volumeControl == null) return;
            _volumeControl.SetMasterVolumeLevelScalar(volume, Guid.Empty);
        }
    }
}
