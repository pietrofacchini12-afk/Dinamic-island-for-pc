using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace DynamicIsland.Services
{
    public class ScreenRecordService
    {
        private bool _isRecordingActive = false;
        public bool IsRecording => _isRecordingActive;

        public event Action<bool>? OnRecordingStateChanged;

        [DllImport("user32.dll")]
        private static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);

        private const byte VK_LWIN = 0x5B;
        private const byte VK_MENU = 0x12; // ALT
        private const byte VK_R = 0x52;
        private const uint KEYEVENTF_KEYUP = 0x0002;

        public bool ToggleRecording()
        {
            if (IsRecording)
            {
                StopRecording();
                return false;
            }
            else
            {
                return StartRecording();
            }
        }

        public bool StartRecording()
        {
            // 1. Try launching Windows Snipping Tool Video Recording mode directly
            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = "ms-screenclip:",
                    UseShellExecute = true
                };
                Process.Start(psi);
                _isRecordingActive = true;
                OnRecordingStateChanged?.Invoke(true);
                return true;
            }
            catch { }

            // 2. Fallback: Trigger Game Bar Recording (Win + Alt + R)
            try
            {
                keybd_event(VK_LWIN, 0, 0, UIntPtr.Zero);
                keybd_event(VK_MENU, 0, 0, UIntPtr.Zero);
                keybd_event(VK_R, 0, 0, UIntPtr.Zero);

                keybd_event(VK_R, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
                keybd_event(VK_MENU, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
                keybd_event(VK_LWIN, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);

                _isRecordingActive = true;
                OnRecordingStateChanged?.Invoke(true);
                return true;
            }
            catch { }

            // 3. Fallback: Open SnippingTool.exe
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = "snippingtool.exe",
                    UseShellExecute = true
                });
                _isRecordingActive = true;
                OnRecordingStateChanged?.Invoke(true);
                return true;
            }
            catch { }

            return false;
        }

        public void StopRecording()
        {
            try
            {
                // Win + Alt + R toggles Game Bar recording off
                keybd_event(VK_LWIN, 0, 0, UIntPtr.Zero);
                keybd_event(VK_MENU, 0, 0, UIntPtr.Zero);
                keybd_event(VK_R, 0, 0, UIntPtr.Zero);

                keybd_event(VK_R, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
                keybd_event(VK_MENU, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
                keybd_event(VK_LWIN, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
            }
            catch { }

            _isRecordingActive = false;
            OnRecordingStateChanged?.Invoke(false);
        }
    }
}
