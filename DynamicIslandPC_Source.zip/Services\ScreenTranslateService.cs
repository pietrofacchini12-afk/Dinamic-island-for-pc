using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows;
using Windows.Graphics.Imaging;
using Windows.Media.Ocr;
using Windows.Storage.Streams;

namespace DynamicIsland.Services
{
    public static class ScreenTranslateService
    {
        private static readonly HttpClient _httpClient = new HttpClient { Timeout = TimeSpan.FromSeconds(12) };

        public static async Task<(string originalText, string translatedText)> CaptureAndTranslateAsync(string targetLang = "pt", System.Drawing.Rectangle? selectionArea = null)
        {
            try
            {
                var bounds = Screen.PrimaryScreen?.Bounds ?? new System.Drawing.Rectangle(0, 0, 1920, 1080);
                using var fullBitmap = new Bitmap(bounds.Width, bounds.Height);
                using (var g = Graphics.FromImage(fullBitmap))
                {
                    g.CopyFromScreen(System.Drawing.Point.Empty, System.Drawing.Point.Empty, bounds.Size);
                }

                Bitmap bitmapToProcess;
                if (selectionArea.HasValue)
                {
                    var area = selectionArea.Value;

                    double scaleX = (double)bounds.Width / SystemParameters.PrimaryScreenWidth;
                    double scaleY = (double)bounds.Height / SystemParameters.PrimaryScreenHeight;

                    int physX = (int)(area.X * scaleX);
                    int physY = (int)(area.Y * scaleY);
                    int physWidth = (int)(area.Width * scaleX);
                    int physHeight = (int)(area.Height * scaleY);

                    physX = Math.Max(0, Math.Min(physX, bounds.Width - 1));
                    physY = Math.Max(0, Math.Min(physY, bounds.Height - 1));
                    physWidth = Math.Max(1, Math.Min(physWidth, bounds.Width - physX));
                    physHeight = Math.Max(1, Math.Min(physHeight, bounds.Height - physY));

                    bitmapToProcess = fullBitmap.Clone(new System.Drawing.Rectangle(physX, physY, physWidth, physHeight), fullBitmap.PixelFormat);
                }
                else
                {
                    bitmapToProcess = (Bitmap)fullBitmap.Clone();
                }

                using (bitmapToProcess)
                {
                    string extractedText = await ExtractTextWithOcrAsync(bitmapToProcess);
                    if (string.IsNullOrWhiteSpace(extractedText))
                    {
                        return ("Nenhum texto detectado na tela.", "Certifique-se de que há texto legível aberto na tela.");
                    }

                    if (extractedText.Length > 800)
                    {
                        extractedText = extractedText.Substring(0, 800) + "...";
                    }

                    string translated = await TranslateTextAsync(extractedText, targetLang);
                    return (extractedText, translated);
                }
            }
            catch (Exception ex)
            {
                return ("Erro ao capturar tela", $"Detalhes: {ex.Message}");
            }
        }

        private static async Task<string> ExtractTextWithOcrAsync(Bitmap bmp)
        {
            try
            {
                using var memoryStream = new MemoryStream();
                bmp.Save(memoryStream, ImageFormat.Bmp);
                memoryStream.Position = 0;

                using var randomAccessStream = new InMemoryRandomAccessStream();
                using var outputStream = randomAccessStream.GetOutputStreamAt(0);
                using var dataWriter = new DataWriter(outputStream);
                dataWriter.WriteBytes(memoryStream.ToArray());
                await dataWriter.StoreAsync();
                await outputStream.FlushAsync();

                var decoder = await BitmapDecoder.CreateAsync(randomAccessStream);
                var softwareBitmap = await decoder.GetSoftwareBitmapAsync();

                var ocrEngine = OcrEngine.TryCreateFromUserProfileLanguages();
                if (ocrEngine == null)
                {
                    // Fallback to English OCR if user profile is unavailable
                    ocrEngine = OcrEngine.TryCreateFromLanguage(new Windows.Globalization.Language("en-US"));
                }

                if (ocrEngine != null)
                {
                    var ocrResult = await ocrEngine.RecognizeAsync(softwareBitmap);
                    return ocrResult.Text;
                }
            }
            catch { }

            return string.Empty;
        }

        public static async Task<string> TranslateTextAsync(string text, string targetLang = "pt")
        {
            if (string.IsNullOrWhiteSpace(text)) return string.Empty;

            try
            {
                // Free Google Translate GTXR API
                string url = $"https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl={targetLang}&dt=t&q={Uri.EscapeDataString(text)}";
                string json = await _httpClient.GetStringAsync(url);
                
                using var doc = JsonDocument.Parse(json);
                var root = doc.RootElement;
                if (root.ValueKind == JsonValueKind.Array && root.GetArrayLength() > 0)
                {
                    var sentences = root[0];
                    var sb = new System.Text.StringBuilder();
                    foreach (var s in sentences.EnumerateArray())
                    {
                        if (s.ValueKind == JsonValueKind.Array && s.GetArrayLength() > 0)
                        {
                            sb.Append(s[0].GetString());
                        }
                    }
                    return sb.ToString().Trim();
                }
            }
            catch
            {
                // Fallback: MyMemory API
                try
                {
                    string url = $"https://api.mymemory.translated.net/get?q={Uri.EscapeDataString(text)}&langpair=autodetect|{targetLang}";
                    string json = await _httpClient.GetStringAsync(url);
                    using var doc = JsonDocument.Parse(json);
                    if (doc.RootElement.TryGetProperty("responseData", out var respData) &&
                        respData.TryGetProperty("translatedText", out var transText))
                    {
                        return transText.GetString() ?? text;
                    }
                }
                catch { }
            }

            return text;
        }
    }
}
