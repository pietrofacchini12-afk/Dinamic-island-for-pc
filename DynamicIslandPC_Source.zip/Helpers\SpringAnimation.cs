using System;
using System.Windows.Media;

namespace DynamicIsland.Helpers
{
    public class SpringAnimation
    {
        public double CurrentWidth { get; private set; }
        public double CurrentHeight { get; private set; }
        public double TargetWidth { get; set; }
        public double TargetHeight { get; set; }

        private double _velocityWidth = 0;
        private double _velocityHeight = 0;

        public double Stiffness { get; set; } = 220.0;
        public double Damping { get; set; } = 20.0;
        public double Mass { get; set; } = 1.0;

        private DateTime _lastUpdate = DateTime.Now;
        private bool _isRunning = false;
        private readonly Action<double, double> _onFrameUpdate;

        public SpringAnimation(double initialWidth, double initialHeight, Action<double, double> onFrameUpdate)
        {
            CurrentWidth = initialWidth;
            CurrentHeight = initialHeight;
            TargetWidth = initialWidth;
            TargetHeight = initialHeight;
            _onFrameUpdate = onFrameUpdate;
        }

        public void Start()
        {
            if (_isRunning) return;
            _isRunning = true;
            _lastUpdate = DateTime.Now;
            CompositionTarget.Rendering += OnRenderFrame;
        }

        public void Stop()
        {
            if (!_isRunning) return;
            _isRunning = false;
            CompositionTarget.Rendering -= OnRenderFrame;
        }

        public void SetTarget(double targetWidth, double targetHeight)
        {
            TargetWidth = targetWidth;
            TargetHeight = targetHeight;
            if (!_isRunning)
            {
                Start();
            }
        }

        private void OnRenderFrame(object? sender, EventArgs e)
        {
            DateTime now = DateTime.Now;
            double dt = (now - _lastUpdate).TotalSeconds;
            _lastUpdate = now;

            if (dt > 0.033) dt = 0.033;
            if (dt <= 0) return;

            double forceW = -Stiffness * (CurrentWidth - TargetWidth);
            double dampingForceW = -Damping * _velocityWidth;
            double accelerationW = (forceW + dampingForceW) / Mass;

            _velocityWidth += accelerationW * dt;
            CurrentWidth += _velocityWidth * dt;

            double forceH = -Stiffness * (CurrentHeight - TargetHeight);
            double dampingForceH = -Damping * _velocityHeight;
            double accelerationH = (forceH + dampingForceH) / Mass;

            _velocityHeight += accelerationH * dt;
            CurrentHeight += _velocityHeight * dt;

            _onFrameUpdate?.Invoke(CurrentWidth, CurrentHeight);

            bool nearWidth = Math.Abs(TargetWidth - CurrentWidth) < 0.2 && Math.Abs(_velocityWidth) < 0.2;
            bool nearHeight = Math.Abs(TargetHeight - CurrentHeight) < 0.2 && Math.Abs(_velocityHeight) < 0.2;

            if (nearWidth && nearHeight)
            {
                CurrentWidth = TargetWidth;
                CurrentHeight = TargetHeight;
                _velocityWidth = 0;
                _velocityHeight = 0;
                _onFrameUpdate?.Invoke(CurrentWidth, CurrentHeight);
                Stop();
            }
        }
    }
}
