using System;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Color = System.Windows.Media.Color;

namespace DynamicIsland.Helpers
{
    public static class ColorExtractor
    {
        public static Color ExtractDominantColor(BitmapSource bitmapSource)
        {
            if (bitmapSource == null) return Color.FromRgb(30, 30, 45);

            try
            {
                var smallBmp = new FormatConvertedBitmap(bitmapSource, PixelFormats.Bgra32, null, 0);
                int width = 16;
                int height = 16;
                int stride = width * 4;
                byte[] pixels = new byte[height * stride];

                smallBmp.CopyPixels(new System.Windows.Int32Rect(0, 0, Math.Min(width, smallBmp.PixelWidth), Math.Min(height, smallBmp.PixelHeight)), pixels, stride, 0);

                long totalR = 0, totalG = 0, totalB = 0;
                int count = 0;

                for (int i = 0; i < pixels.Length; i += 4)
                {
                    byte b = pixels[i];
                    byte g = pixels[i + 1];
                    byte r = pixels[i + 2];
                    byte a = pixels[i + 3];

                    if (a > 128)
                    {
                        totalR += r;
                        totalG += g;
                        totalB += b;
                        count++;
                    }
                }

                if (count == 0) return Color.FromRgb(30, 35, 50);

                byte avgR = (byte)Math.Clamp(totalR / count, 20, 220);
                byte avgG = (byte)Math.Clamp(totalG / count, 20, 220);
                byte avgB = (byte)Math.Clamp(totalB / count, 20, 220);

                return Color.FromRgb(avgR, avgG, avgB);
            }
            catch
            {
                return Color.FromRgb(25, 30, 45);
            }
        }
    }
}
